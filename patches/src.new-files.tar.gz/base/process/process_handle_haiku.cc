// Copyright 2026 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "base/process/process_handle.h"

#include <OS.h>
#include <image.h>

#include "base/files/file_path.h"

namespace base {

// A team's executable is its B_APP_IMAGE; there is no /proc/<pid>/exe.
FilePath GetProcessExecutablePath(ProcessHandle process) {
  image_info info;
  int32 cookie = 0;
  while (get_next_image_info(process, &cookie, &info) == B_OK) {
    if (info.type == B_APP_IMAGE) {
      return FilePath(info.name);
    }
  }
  return FilePath();
}

}  // namespace base
