// Copyright 2026 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Haiku implementations of the //chrome/browser hooks that every other
// desktop platform provides in a *_linux.cc / *_mac.mm / *_win.cc file. Most
// are "not supported here" answers; files and URLs are handed to Haiku's
// `open` command.

#include <unistd.h>

#include <memory>
#include <optional>
#include <set>
#include <string>
#include <vector>

#include "base/command_line.h"
#include "base/files/file_path.h"
#include "base/functional/bind.h"
#include "base/functional/callback.h"
#include "base/path_service.h"
#include "base/base_paths.h"
#include "base/process/launch.h"
#include "base/process/process_handle.h"
#include "base/strings/utf_string_conversions.h"
#include "base/task/sequenced_task_runner.h"
#include "base/task/task_runner.h"
#include "base/task/thread_pool.h"
#include "base/version_info/version_info.h"
#include "chrome/browser/download/download_status_updater.h"
#include "chrome/browser/extensions/api/image_writer_private/removable_storage_provider.h"
#include "chrome/browser/first_run/first_run_internal.h"
#include "chrome/browser/icon_loader.h"
#include "chrome/browser/memory_details.h"
#include "chrome/browser/notifications/notification_platform_bridge.h"
#include "chrome/browser/platform_util.h"
#include "chrome/browser/platform_util_internal.h"
#include "chrome/browser/printing/printer_manager_dialog.h"
#include "chrome/browser/shell_integration.h"
#include "chrome/browser/shortcuts/shortcut_creator.h"
#include "chrome/browser/status_icons/status_tray.h"
#include "chrome/browser/ui/webui/settings/settings_utils.h"
#include "chrome/browser/web_applications/icons/icon_masker.h"
#include "chrome/browser/web_applications/os_integration/web_app_file_handler_registration.h"
#include "chrome/browser/web_applications/os_integration/web_app_shortcut.h"
#include "content/public/browser/browser_task_traits.h"
#include "content/public/browser/browser_thread.h"
#include "components/device_signals/core/browser/browser_utils.h"
#include "components/device_signals/core/common/common_types.h"
#include "components/device_signals/core/common/platform_utils.h"
#include "content/public/common/process_type.h"
#include "chrome/installer/util/initial_preferences.h"
#include "extensions/browser/api/system_cpu/cpu_info_provider.h"
#include "net/base/network_interfaces.h"
#include "third_party/skia/include/core/SkBitmap.h"
#include "ui/gfx/image/image.h"
#include "url/gurl.h"

namespace {

// Hands |target| to Haiku's `open`, which resolves URLs and files through the
// registrar the same way Tracker does.
void HaikuOpen(const std::string& target) {
  base::CommandLine command(base::FilePath("/bin/open"));
  command.AppendArg(target);
  base::LaunchProcess(command, base::LaunchOptions());
}

}  // namespace

// --- platform_util ----------------------------------------------------------

namespace platform_util {

void ShowItemInFolder(Profile* profile, const base::FilePath& full_path) {
  HaikuOpen(full_path.DirName().value());
}

void OpenExternal(const GURL& url) {
  HaikuOpen(url.spec());
}

namespace internal {

void PlatformOpenVerifiedItem(const base::FilePath& path, OpenItemType type) {
  HaikuOpen(path.value());
}

}  // namespace internal
}  // namespace platform_util

// --- shell_integration ------------------------------------------------------

namespace shell_integration {

bool SetAsDefaultBrowser() {
  return false;
}

bool SetAsDefaultClientForScheme(const std::string& scheme) {
  return false;
}

std::u16string GetApplicationNameForScheme(const GURL& url) {
  return std::u16string();
}

DefaultWebClientState GetDefaultBrowser() {
  return UNKNOWN_DEFAULT;
}

DefaultWebClientState IsDefaultClientForScheme(const std::string& scheme) {
  return UNKNOWN_DEFAULT;
}

std::string GetDirectLaunchUrlScheme() {
  return std::string();
}

namespace internal {

DefaultWebClientSetPermission GetPlatformSpecificDefaultWebClientSetPermission(
    WebClientSetMethod method) {
  return SET_DEFAULT_NOT_ALLOWED;
}

}  // namespace internal
}  // namespace shell_integration

// --- Desktop shortcuts and web app OS integration ---------------------------

namespace shortcuts {

void CreateShortcutOnUserDesktop(ShortcutMetadata shortcut_metadata,
                                 ShortcutCreatorCallback complete) {
  std::move(complete).Run(base::FilePath(), ShortcutCreatorResult::kError);
}

scoped_refptr<base::SequencedTaskRunner> GetShortcutsTaskRunner() {
  return base::ThreadPool::CreateSequencedTaskRunner({base::MayBlock()});
}

}  // namespace shortcuts

namespace web_app {

void MaskIconOnOs(SkBitmap input_bitmap, MaskedIconCallback masked_callback) {
  std::move(masked_callback).Run(std::move(input_bitmap));
}

bool ShouldRegisterFileHandlersWithOs() {
  return false;
}

void RegisterFileHandlersWithOs(const webapps::AppId& app_id,
                                const std::string& app_name,
                                const base::FilePath& profile_path,
                                const apps::FileHandlers& file_handlers,
                                ResultCallback callback) {
  std::move(callback).Run(Result::kOk);
}

void UnregisterFileHandlersWithOs(const webapps::AppId& app_id,
                                  const base::FilePath& profile_path,
                                  ResultCallback callback) {
  std::move(callback).Run(Result::kOk);
}

namespace internals {

void CreatePlatformShortcuts(const base::FilePath& shortcut_data_path,
                             const ShortcutLocations& creation_locations,
                             ShortcutCreationReason creation_reason,
                             const ShortcutInfo& shortcut_info,
                             CreateShortcutsCallback callback) {
  std::move(callback).Run(false);
}

ShortcutLocations GetAppExistingShortCutLocationImpl(
    const ShortcutInfo& shortcut_info) {
  return ShortcutLocations();
}

void DeletePlatformShortcuts(const base::FilePath& shortcut_data_path,
                             const ShortcutInfo& shortcut_info,
                             scoped_refptr<base::TaskRunner> result_runner,
                             DeleteShortcutsCallback callback) {
  result_runner->PostTask(FROM_HERE,
                          base::BindOnce(std::move(callback), true));
}

void UpdatePlatformShortcuts(
    const base::FilePath& shortcut_data_path,
    const std::u16string& old_app_title,
    std::optional<ShortcutLocations> user_specified_locations,
    ResultCallback callback,
    const ShortcutInfo& shortcut_info) {
  std::move(callback).Run(Result::kOk);
}

void DeleteAllShortcutsForProfile(const base::FilePath& profile_path) {}

}  // namespace internals
}  // namespace web_app

// --- Notifications, status tray, downloads ----------------------------------

namespace {

// Haiku has no notification server binding, and Chrome's message center is
// compiled out (enable_chrome_notifications is Mac/Win/Linux only), so the
// delegator needs a "system" bridge that is ready and handles every type.
// Notifications are dropped.
class NotificationPlatformBridgeHaiku : public NotificationPlatformBridge {
 public:
  NotificationPlatformBridgeHaiku() = default;
  ~NotificationPlatformBridgeHaiku() override = default;

  void Display(NotificationHandler::Type notification_type,
               Profile* profile,
               const message_center::Notification& notification,
               std::unique_ptr<NotificationCommon::Metadata> metadata) override {
  }
  void Close(Profile* profile, const std::string& notification_id) override {}
  void GetDisplayed(Profile* profile,
                    GetDisplayedNotificationsCallback callback) const override {
    std::move(callback).Run(std::set<std::string>(),
                            /*supports_synchronization=*/true);
  }
  void GetDisplayedForOrigin(
      Profile* profile,
      const GURL& origin,
      GetDisplayedNotificationsCallback callback) const override {
    std::move(callback).Run(std::set<std::string>(),
                            /*supports_synchronization=*/true);
  }
  void SetReadyCallback(NotificationBridgeReadyCallback callback) override {
    std::move(callback).Run(true);
  }
  void DisplayServiceShutDown(Profile* profile) override {}
};

}  // namespace

std::unique_ptr<NotificationPlatformBridge>
NotificationPlatformBridge::Create() {
  return std::make_unique<NotificationPlatformBridgeHaiku>();
}

bool NotificationPlatformBridge::CanHandleType(
    NotificationHandler::Type notification_type) {
  return true;
}

std::unique_ptr<StatusTray> StatusTray::Create() {
  return nullptr;
}

void DownloadStatusUpdater::UpdateAppIconDownloadProgress(
    download::DownloadItem* download) {}

// --- File type icons --------------------------------------------------------

IconLoader::IconGroup IconLoader::GroupForFilepath(
    const base::FilePath& file_path) {
  return file_path.Extension();
}

scoped_refptr<base::TaskRunner> IconLoader::GetReadIconTaskRunner() {
  return content::GetUIThreadTaskRunner({});
}

void IconLoader::ReadIcon() {
  target_task_runner_->PostTask(
      FROM_HERE, base::BindOnce(std::move(callback_), gfx::Image(), group_));
  delete this;
}

// --- about:memory -----------------------------------------------------------

MemoryDetails::MemoryDetails() = default;

ProcessData* MemoryDetails::ChromeBrowser() {
  return &process_data_[0];
}

// Haiku runs Chrome --single-process, so the browser is the only process.
void MemoryDetails::CollectProcessData(
    const std::vector<ProcessMemoryInformation>& child_info) {
  ProcessData current_browser;
  ProcessMemoryInformation pmi;
  pmi.pid = base::GetCurrentProcId();
  pmi.num_processes = 1;
  pmi.process_type = content::PROCESS_TYPE_BROWSER;
  current_browser.processes.push_back(pmi);
  current_browser.name = base::ASCIIToUTF16(version_info::GetProductName());
  current_browser.process_name = u"chrome";
  process_data_.push_back(current_browser);

  content::GetUIThreadTaskRunner({})->PostTask(
      FROM_HERE,
      base::BindOnce(&MemoryDetails::CollectChildInfoOnUIThread, this));
}

// --- Misc system integration ------------------------------------------------

namespace printing {

// static
void PrinterManagerDialog::ShowPrinterManagerDialog() {
  HaikuOpen("/boot/system/preferences/Printers");
}

}  // namespace printing

namespace settings_utils {

void ShowNetworkProxySettings(content::WebContents* web_contents) {
  HaikuOpen("/boot/system/preferences/Network");
}

}  // namespace settings_utils

namespace extensions {

bool CpuInfoProvider::QueryCpuTimePerProcessor(
    std::vector<api::system_cpu::ProcessorInfo>* infos) {
  return false;
}

// static
scoped_refptr<StorageDeviceList>
RemovableStorageProvider::PopulateDeviceList() {
  return nullptr;
}

}  // namespace extensions

// --- First run, relaunch, sync device name -----------------------------------

namespace first_run::internal {

// Like Linux: initial prefs live next to the executable.
base::FilePath InitialPrefsPath() {
  base::FilePath dir_exe;
  if (!base::PathService::Get(base::DIR_EXE, &dir_exe)) {
    return base::FilePath();
  }
  return installer::InitialPreferences::Path(dir_exe);
}

}  // namespace first_run::internal

namespace upgrade_util {

bool RelaunchChromeBrowserImpl(const base::CommandLine& command_line) {
  return base::LaunchProcess(command_line, base::LaunchOptions()).IsValid();
}

}  // namespace upgrade_util

namespace syncer {

std::string GetPersonalizableDeviceNameInternal() {
  char hostname[256];
  if (gethostname(hostname, sizeof(hostname)) == 0) {
    hostname[sizeof(hostname) - 1] = '\0';
    return hostname;
  }
  return "Haiku";
}

}  // namespace syncer

// --- Device signals (enterprise context-aware access) ------------------------

namespace device_signals {

std::string GetHostName() {
  return net::GetHostName();
}

std::string GetSerialNumber() {
  return std::string();
}

SettingValue GetScreenlockSecured() {
  return SettingValue::UNKNOWN;
}

SettingValue GetDiskEncrypted() {
  return SettingValue::UNKNOWN;
}

}  // namespace device_signals
