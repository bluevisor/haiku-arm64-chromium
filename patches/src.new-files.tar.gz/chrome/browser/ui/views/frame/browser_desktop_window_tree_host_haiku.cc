// Copyright 2026 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "chrome/browser/ui/views/frame/browser_desktop_window_tree_host.h"

#include "ui/views/widget/desktop_aura/desktop_window_tree_host_platform.h"

namespace {

// The plain ozone desktop host: Haiku's app_server decorates nothing that the
// opaque browser frame draws, so there is no Linux-style frame hint plumbing.
class BrowserDesktopWindowTreeHostHaiku
    : public BrowserDesktopWindowTreeHost,
      public views::DesktopWindowTreeHostPlatform {
 public:
  BrowserDesktopWindowTreeHostHaiku(
      views::internal::NativeWidgetDelegate* native_widget_delegate,
      views::DesktopNativeWidgetAura* desktop_native_widget_aura)
      : views::DesktopWindowTreeHostPlatform(native_widget_delegate,
                                             desktop_native_widget_aura) {}
  BrowserDesktopWindowTreeHostHaiku(const BrowserDesktopWindowTreeHostHaiku&) =
      delete;
  BrowserDesktopWindowTreeHostHaiku& operator=(
      const BrowserDesktopWindowTreeHostHaiku&) = delete;
  ~BrowserDesktopWindowTreeHostHaiku() override = default;

  // BrowserDesktopWindowTreeHost:
  views::DesktopWindowTreeHost* AsDesktopWindowTreeHost() override {
    return this;
  }
  bool UsesNativeSystemMenu() const override { return false; }
};

}  // namespace

// static
BrowserDesktopWindowTreeHost*
BrowserDesktopWindowTreeHost::CreateBrowserDesktopWindowTreeHost(
    views::internal::NativeWidgetDelegate* native_widget_delegate,
    views::DesktopNativeWidgetAura* desktop_native_widget_aura,
    BrowserView* browser_view,
    BrowserWidget* browser_widget) {
  return new BrowserDesktopWindowTreeHostHaiku(native_widget_delegate,
                                               desktop_native_widget_aura);
}
