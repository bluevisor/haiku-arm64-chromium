// Copyright 2026 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Haiku: crashpad has no Haiku port, so crash reporting is a no-op here.

#include "components/crash/core/app/crashpad.h"

#include "base/immediate_crash.h"

namespace crash_reporter {

bool InitializeCrashpad(bool initial_client, const std::string& process_type) {
  return false;
}

crashpad::CrashpadClient& GetCrashpadClient() {
  base::ImmediateCrash();
}

void DestroyCrashpadClient() {}

void SetUploadConsent(bool consent) {}

void GetReports(std::vector<Report>* reports) {
  reports->clear();
}

void RequestSingleCrashUpload(const std::string& local_id) {}

void DumpWithoutCrashing() {}

std::optional<base::FilePath> GetCrashpadDatabasePath() {
  return std::nullopt;
}

void ClearReportsBetween(const base::Time& begin, const base::Time& end) {}

void GetReportsImpl(std::vector<Report>* reports) {
  reports->clear();
}

void RequestSingleCrashUploadImpl(const std::string& local_id) {}

base::FilePath::StringType::const_pointer GetCrashpadDatabasePathImpl() {
  return nullptr;
}

void ClearReportsBetweenImpl(time_t begin, time_t end) {}

}  // namespace crash_reporter
