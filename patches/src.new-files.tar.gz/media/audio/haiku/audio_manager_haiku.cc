// Copyright 2026 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "media/audio/haiku/audio_manager_haiku.h"

#include <algorithm>
#include <memory>

#include "base/command_line.h"
#include "media/audio/audio_device_description.h"
#include "media/audio/haiku/audio_output_stream_haiku.h"
#include "media/base/audio_parameters.h"
#include "media/base/media_switches.h"

namespace media {

namespace {

// The media kit mixes at its own rate and buffer size; 48 kHz stereo with a
// 20 ms buffer is close to what hmulti_audio asks the driver for.
constexpr int kSampleRate = 48000;
constexpr int kFramesPerBuffer = 960;
constexpr int kMinFramesPerBuffer = 480;
constexpr int kMaxFramesPerBuffer = 4096;

}  // namespace

std::unique_ptr<media::AudioManager> CreateAudioManager(
    std::unique_ptr<AudioThread> audio_thread,
    AudioLogFactory* audio_log_factory) {
  return std::make_unique<AudioManagerHaiku>(std::move(audio_thread),
                                             audio_log_factory);
}

AudioManagerHaiku::AudioManagerHaiku(std::unique_ptr<AudioThread> audio_thread,
                                     AudioLogFactory* audio_log_factory)
    : AudioManagerBase(std::move(audio_thread), audio_log_factory) {}

AudioManagerHaiku::~AudioManagerHaiku() = default;

bool AudioManagerHaiku::HasAudioOutputDevices() {
  return !base::CommandLine::ForCurrentProcess()->HasSwitch(
      switches::kDisableAudioOutput);
}

bool AudioManagerHaiku::HasAudioInputDevices() {
  return false;
}

bool AudioManagerHaiku::GetAudioInputDeviceNames(
    AudioDeviceNames* device_names) {
  DCHECK(device_names->empty());
  return true;
}

bool AudioManagerHaiku::GetAudioOutputDeviceNames(
    AudioDeviceNames* device_names) {
  DCHECK(device_names->empty());
  if (HasAudioOutputDevices()) {
    device_names->push_back(AudioDeviceName::CreateDefault());
  }
  return true;
}

AudioParameters AudioManagerHaiku::GetInputStreamParameters(
    const std::string& device_id) {
  return AudioParameters();
}

const std::string_view AudioManagerHaiku::GetName() {
  return "Haiku";
}

AudioOutputStream* AudioManagerHaiku::MakeLinearOutputStream(
    const AudioParameters& params,
    const LogCallback& log_callback) {
  DCHECK_EQ(AudioParameters::AUDIO_PCM_LINEAR, params.format());
  return new AudioOutputStreamHaiku(this, params);
}

AudioOutputStream* AudioManagerHaiku::MakeLowLatencyOutputStream(
    const AudioParameters& params,
    const std::string& device_id,
    const LogCallback& log_callback) {
  DCHECK_EQ(AudioParameters::AUDIO_PCM_LOW_LATENCY, params.format());
  if (!device_id.empty() &&
      !AudioDeviceDescription::IsDefaultDevice(device_id)) {
    return nullptr;
  }
  return new AudioOutputStreamHaiku(this, params);
}

AudioInputStream* AudioManagerHaiku::MakeLinearInputStream(
    const AudioParameters& params,
    const std::string& device_id,
    const LogCallback& log_callback) {
  return nullptr;
}

AudioInputStream* AudioManagerHaiku::MakeLowLatencyInputStream(
    const AudioParameters& params,
    const std::string& device_id,
    const LogCallback& log_callback) {
  return nullptr;
}

AudioParameters AudioManagerHaiku::GetPreferredOutputStreamParameters(
    const std::string& output_device_id,
    const AudioParameters& input_params) {
  int sample_rate = kSampleRate;
  ChannelLayoutConfig channel_layout = ChannelLayoutConfig::Stereo();
  int frames = kFramesPerBuffer;
  if (input_params.IsValid()) {
    sample_rate = input_params.sample_rate();
    if (input_params.channels() <= 2) {
      channel_layout = input_params.channel_layout_config();
    }
    frames = std::clamp(input_params.frames_per_buffer(), kMinFramesPerBuffer,
                        kMaxFramesPerBuffer);
  }
  return AudioParameters(
      AudioParameters::AUDIO_PCM_LOW_LATENCY, channel_layout, sample_rate,
      frames,
      AudioParameters::HardwareCapabilities(kMinFramesPerBuffer,
                                            kMaxFramesPerBuffer));
}

}  // namespace media
