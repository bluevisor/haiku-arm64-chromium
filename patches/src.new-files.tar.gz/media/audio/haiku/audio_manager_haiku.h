// Copyright 2026 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef MEDIA_AUDIO_HAIKU_AUDIO_MANAGER_HAIKU_H_
#define MEDIA_AUDIO_HAIKU_AUDIO_MANAGER_HAIKU_H_

#include <memory>
#include <string>
#include <string_view>

#include "media/audio/audio_manager_base.h"

namespace media {

// Output through the media kit (see AudioOutputStreamHaiku); no input.
class AudioManagerHaiku : public AudioManagerBase {
 public:
  AudioManagerHaiku(std::unique_ptr<AudioThread> audio_thread,
                    AudioLogFactory* audio_log_factory);
  AudioManagerHaiku(const AudioManagerHaiku&) = delete;
  AudioManagerHaiku& operator=(const AudioManagerHaiku&) = delete;
  ~AudioManagerHaiku() override;

  // AudioManager:
  bool HasAudioOutputDevices() override;
  bool HasAudioInputDevices() override;
  bool GetAudioInputDeviceNames(AudioDeviceNames* device_names) override;
  bool GetAudioOutputDeviceNames(AudioDeviceNames* device_names) override;
  AudioParameters GetInputStreamParameters(
      const std::string& device_id) override;
  const std::string_view GetName() override;

  // AudioManagerBase:
  AudioOutputStream* MakeLinearOutputStream(
      const AudioParameters& params,
      const LogCallback& log_callback) override;
  AudioOutputStream* MakeLowLatencyOutputStream(
      const AudioParameters& params,
      const std::string& device_id,
      const LogCallback& log_callback) override;
  AudioInputStream* MakeLinearInputStream(
      const AudioParameters& params,
      const std::string& device_id,
      const LogCallback& log_callback) override;
  AudioInputStream* MakeLowLatencyInputStream(
      const AudioParameters& params,
      const std::string& device_id,
      const LogCallback& log_callback) override;

 protected:
  AudioParameters GetPreferredOutputStreamParameters(
      const std::string& output_device_id,
      const AudioParameters& input_params) override;
};

}  // namespace media

#endif  // MEDIA_AUDIO_HAIKU_AUDIO_MANAGER_HAIKU_H_
