// Copyright 2026 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "media/audio/haiku/audio_output_stream_haiku.h"

#include <algorithm>

#include "base/compiler_specific.h"
#include "base/containers/span.h"
#include "base/logging.h"
#include "base/time/time.h"
#include "media/audio/haiku/audio_manager_haiku.h"
#include "media/base/audio_bus.h"
#include "media/base/audio_glitch_info.h"
#include "media/base/audio_sample_types.h"
#include "media/base/audio_timestamp_helper.h"

namespace media {

AudioOutputStreamHaiku::AudioOutputStreamHaiku(AudioManagerHaiku* manager,
                                               const AudioParameters& params)
    : manager_(manager), params_(params) {}

AudioOutputStreamHaiku::~AudioOutputStreamHaiku() = default;

bool AudioOutputStreamHaiku::Open() {
  DCHECK(!player_);
  {
    base::AutoLock guard(lock_);
    bus_ = AudioBus::Create(params_);
    // Enough for the media kit's largest usual buffer plus one source fill.
    const int fifo_frames =
        std::max(8192, params_.frames_per_buffer() * 4);
    out_bus_ = AudioBus::Create(params_.channels(), fifo_frames);
    fifo_ = std::make_unique<AudioFifo>(params_.channels(), fifo_frames * 2);
  }
  player_ = haiku_shim::HaikuShimSoundPlayerCreate(
      params_.sample_rate(), params_.channels(), params_.frames_per_buffer(),
      &AudioOutputStreamHaiku::FillThunk, this);
  if (!player_) {
    LOG(ERROR) << "No media server: audio output unavailable";
    return false;
  }
  return true;
}

void AudioOutputStreamHaiku::Start(AudioSourceCallback* callback) {
  DCHECK(player_);
  {
    base::AutoLock guard(lock_);
    callback_ = callback;
    fifo_->Clear();
  }
  if (!haiku_shim::HaikuShimSoundPlayerStart(player_)) {
    base::AutoLock guard(lock_);
    callback_ = nullptr;
    callback->OnError(AudioSourceCallback::ErrorType::kUnknown);
    return;
  }
  latency_us_.store(haiku_shim::HaikuShimSoundPlayerLatencyUs(player_),
                    std::memory_order_relaxed);
}

void AudioOutputStreamHaiku::Stop() {
  if (!player_) {
    return;
  }
  // Stop blocks until the media kit thread is out of Fill(), so clearing the
  // callback afterwards is safe.
  haiku_shim::HaikuShimSoundPlayerStop(player_);
  base::AutoLock guard(lock_);
  callback_ = nullptr;
}

void AudioOutputStreamHaiku::Flush() {}

void AudioOutputStreamHaiku::SetVolume(double volume) {
  volume_ = std::clamp(volume, 0.0, 1.0);
  if (player_) {
    haiku_shim::HaikuShimSoundPlayerSetVolume(player_,
                                              static_cast<float>(volume_));
  }
}

void AudioOutputStreamHaiku::GetVolume(double* volume) {
  *volume = volume_;
}

void AudioOutputStreamHaiku::Close() {
  Stop();
  if (player_) {
    haiku_shim::HaikuShimSoundPlayerDestroy(player_);
    player_ = nullptr;
  }
  // Deletes this.
  manager_->ReleaseOutputStream(this);
}

// static
void AudioOutputStreamHaiku::FillThunk(void* cookie,
                                       float* interleaved,
                                       size_t frames) {
  static_cast<AudioOutputStreamHaiku*>(cookie)->Fill(interleaved, frames);
}

void AudioOutputStreamHaiku::Fill(float* interleaved, size_t frames) {
  base::AutoLock guard(lock_);
  const int channels = params_.channels();
  if (!callback_ || frames == 0) {
    std::fill(interleaved, interleaved + frames * channels, 0.0f);
    return;
  }
  // Pull from the source until the FIFO can cover this buffer.
  while (fifo_->frames() < static_cast<int>(frames) &&
         fifo_->frames() + bus_->frames() <=
             static_cast<int>(fifo_->max_frames())) {
    // Never call back into the media kit from here (see latency_us_).
    const base::TimeDelta delay =
        base::Microseconds(latency_us_.load(std::memory_order_relaxed)) +
        AudioTimestampHelper::FramesToTime(fifo_->frames(),
                                           params_.sample_rate());
    const int got = callback_->OnMoreData(delay, base::TimeTicks::Now(),
                                          AudioGlitchInfo(), bus_.get());
    if (got <= 0) {
      break;
    }
    fifo_->Push(bus_.get(), got);
  }
  int done = 0;
  while (done < static_cast<int>(frames)) {
    const int chunk =
        std::min({static_cast<int>(frames) - done,
                  static_cast<int>(fifo_->frames()), out_bus_->frames()});
    if (chunk <= 0) {
      break;
    }
    fifo_->Consume(out_bus_.get(), 0, chunk);
    // SAFETY: interleaved holds frames * channels floats (the media kit's
    // buffer for this callback) and done + chunk <= frames.
    out_bus_->ToInterleavedPartial<Float32SampleTypeTraits>(
        0, UNSAFE_BUFFERS(base::span(
               interleaved + static_cast<size_t>(done) * channels,
               static_cast<size_t>(chunk) * channels)));
    done += chunk;
  }
  if (done < static_cast<int>(frames)) {
    std::fill(interleaved + static_cast<size_t>(done) * channels,
              interleaved + frames * channels, 0.0f);
  }
}

}  // namespace media
