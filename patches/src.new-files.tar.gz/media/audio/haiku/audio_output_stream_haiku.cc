// Copyright 2026 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "media/audio/haiku/audio_output_stream_haiku.h"

#include <algorithm>

#include "base/compiler_specific.h"
#include "base/containers/span.h"
#include "base/logging.h"
#include "base/time/time.h"
#include "media/audio/haiku/audio_manager_haiku.h"
#include "media/base/audio_bus.h"
#include "media/base/audio_glitch_info.h"
#include "media/base/audio_sample_types.h"
#include "media/base/audio_timestamp_helper.h"

namespace media {

namespace {

// Three source buffers ahead is enough for a renderer busy decoding video;
// it adds that much to the delay reported to the source.
constexpr int kPrefetchBuffers = 3;

}  // namespace

AudioOutputStreamHaiku::AudioOutputStreamHaiku(AudioManagerHaiku* manager,
                                               const AudioParameters& params)
    : manager_(manager),
      params_(params),
      target_frames_(params.frames_per_buffer() * kPrefetchBuffers) {}

AudioOutputStreamHaiku::~AudioOutputStreamHaiku() = default;

bool AudioOutputStreamHaiku::Open() {
  DCHECK(!player_);
  bus_ = AudioBus::Create(params_);
  {
    base::AutoLock guard(lock_);
    // Room for the prefetch plus the media kit's largest usual buffer.
    const int fifo_frames = std::max(8192, target_frames_ * 2);
    out_bus_ = AudioBus::Create(params_.channels(), fifo_frames);
    fifo_ = std::make_unique<AudioFifo>(params_.channels(), fifo_frames);
  }
  player_ = haiku_shim::HaikuShimSoundPlayerCreate(
      params_.sample_rate(), params_.channels(), params_.frames_per_buffer(),
      &AudioOutputStreamHaiku::FillThunk, this);
  if (!player_) {
    LOG(ERROR) << "No media server: audio output unavailable";
    return false;
  }
  return true;
}

void AudioOutputStreamHaiku::Start(AudioSourceCallback* callback) {
  DCHECK(player_);
  DCHECK(!pump_);
  {
    base::AutoLock guard(lock_);
    callback_ = callback;
    stopping_ = false;
    underrun_frames_ = 0;
    fifo_->Clear();
  }
  // Prefill before the media kit starts asking.
  pump_ = std::make_unique<base::DelegateSimpleThread>(
      this, "HaikuAudioPump",
      base::SimpleThread::Options(base::ThreadType::kRealtimeAudio));
  pump_->Start();
  if (!haiku_shim::HaikuShimSoundPlayerStart(player_)) {
    Stop();
    callback->OnError(AudioSourceCallback::ErrorType::kUnknown);
    return;
  }
  latency_us_.store(haiku_shim::HaikuShimSoundPlayerLatencyUs(player_),
                    std::memory_order_relaxed);
}

void AudioOutputStreamHaiku::Stop() {
  if (!player_) {
    return;
  }
  // Stop blocks until the media kit thread is out of Fill().
  haiku_shim::HaikuShimSoundPlayerStop(player_);
  {
    base::AutoLock guard(lock_);
    stopping_ = true;
    fifo_cv_.Broadcast();
  }
  if (pump_) {
    pump_->Join();
    pump_.reset();
  }
  base::AutoLock guard(lock_);
  callback_ = nullptr;
}

void AudioOutputStreamHaiku::Flush() {}

void AudioOutputStreamHaiku::SetVolume(double volume) {
  volume_ = std::clamp(volume, 0.0, 1.0);
  if (player_) {
    haiku_shim::HaikuShimSoundPlayerSetVolume(player_,
                                              static_cast<float>(volume_));
  }
}

void AudioOutputStreamHaiku::GetVolume(double* volume) {
  *volume = volume_;
}

void AudioOutputStreamHaiku::Close() {
  Stop();
  if (player_) {
    haiku_shim::HaikuShimSoundPlayerDestroy(player_);
    player_ = nullptr;
  }
  // Deletes this.
  manager_->ReleaseOutputStream(this);
}

void AudioOutputStreamHaiku::Run() {
  while (true) {
    AudioSourceCallback* callback = nullptr;
    base::TimeDelta delay;
    AudioGlitchInfo glitch;
    {
      base::AutoLock guard(lock_);
      while (!stopping_ && fifo_->frames() >= static_cast<size_t>(target_frames_)) {
        fifo_cv_.Wait();
      }
      if (stopping_) {
        return;
      }
      callback = callback_;
      delay = base::Microseconds(latency_us_.load(std::memory_order_relaxed)) +
              AudioTimestampHelper::FramesToTime(fifo_->frames(),
                                                 params_.sample_rate());
      if (underrun_frames_ > 0) {
        glitch.duration = AudioTimestampHelper::FramesToTime(
            underrun_frames_, params_.sample_rate());
        glitch.count = 1;
        underrun_frames_ = 0;
      }
    }
    // The source may block here (sync socket to the renderer); the media kit
    // thread keeps draining the FIFO meanwhile.
    const int got = callback->OnMoreData(delay, base::TimeTicks::Now(), glitch,
                                         bus_.get());
    base::AutoLock guard(lock_);
    if (got > 0 &&
        fifo_->frames() + static_cast<size_t>(got) <= fifo_->max_frames()) {
      fifo_->Push(bus_.get(), got);
    }
  }
}

// static
void AudioOutputStreamHaiku::FillThunk(void* cookie,
                                       float* interleaved,
                                       size_t frames) {
  static_cast<AudioOutputStreamHaiku*>(cookie)->Fill(interleaved, frames);
}

void AudioOutputStreamHaiku::Fill(float* interleaved, size_t frames) {
  base::AutoLock guard(lock_);
  const int channels = params_.channels();
  int done = 0;
  if (callback_ && !stopping_) {
    while (done < static_cast<int>(frames)) {
      const int chunk =
          std::min({static_cast<int>(frames) - done,
                    static_cast<int>(fifo_->frames()), out_bus_->frames()});
      if (chunk <= 0) {
        break;
      }
      fifo_->Consume(out_bus_.get(), 0, chunk);
      // SAFETY: interleaved holds frames * channels floats (the media kit's
      // buffer for this callback) and done + chunk <= frames.
      out_bus_->ToInterleavedPartial<Float32SampleTypeTraits>(
          0, UNSAFE_BUFFERS(base::span(
                 interleaved + static_cast<size_t>(done) * channels,
                 static_cast<size_t>(chunk) * channels)));
      done += chunk;
    }
    if (done < static_cast<int>(frames)) {
      underrun_frames_ += static_cast<int>(frames) - done;
      if (++underruns_total_ <= 5 || underruns_total_ % 100 == 0) {
        LOG(WARNING) << "Haiku audio underrun #" << underruns_total_ << ": "
                     << (static_cast<int>(frames) - done) << " of " << frames
                     << " frames";
      }
    }
    if (fifo_->frames() < static_cast<size_t>(target_frames_)) {
      fifo_cv_.Signal();
    }
  }
  if (done < static_cast<int>(frames)) {
    std::fill(interleaved + static_cast<size_t>(done) * channels,
              interleaved + frames * channels, 0.0f);
  }
}

}  // namespace media
