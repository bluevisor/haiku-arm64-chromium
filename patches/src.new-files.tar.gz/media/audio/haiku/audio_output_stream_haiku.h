// Copyright 2026 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef MEDIA_AUDIO_HAIKU_AUDIO_OUTPUT_STREAM_HAIKU_H_
#define MEDIA_AUDIO_HAIKU_AUDIO_OUTPUT_STREAM_HAIKU_H_

#include <atomic>
#include <memory>

#include "base/memory/raw_ptr.h"
#include "base/synchronization/condition_variable.h"
#include "base/synchronization/lock.h"
#include "base/threading/simple_thread.h"
#include "media/audio/audio_io.h"
#include "media/audio/haiku/haiku_sound_shim.h"
#include "media/base/audio_fifo.h"
#include "media/base/audio_parameters.h"

namespace media {

class AudioBus;
class AudioManagerHaiku;

// Plays through the media kit's BSoundPlayer (in the shim). The media kit
// pulls on its own thread, in buffers of its own size, and that thread must
// never wait: it also runs the player node's control loop, and the source
// (the renderer, through the audio service's sync socket) can be late.
// So a pump thread of our own calls OnMoreData() ahead of time into a FIFO,
// and the media kit callback only drains the FIFO.
class AudioOutputStreamHaiku : public AudioOutputStream,
                               public base::DelegateSimpleThread::Delegate {
 public:
  AudioOutputStreamHaiku(AudioManagerHaiku* manager,
                         const AudioParameters& params);
  AudioOutputStreamHaiku(const AudioOutputStreamHaiku&) = delete;
  AudioOutputStreamHaiku& operator=(const AudioOutputStreamHaiku&) = delete;

  // AudioOutputStream:
  bool Open() override;
  void Start(AudioSourceCallback* callback) override;
  void Stop() override;
  void Flush() override;
  void SetVolume(double volume) override;
  void GetVolume(double* volume) override;
  void Close() override;

  // base::DelegateSimpleThread::Delegate: the pump thread.
  void Run() override;

 private:
  ~AudioOutputStreamHaiku() override;

  // Media kit thread.
  static void FillThunk(void* cookie, float* interleaved, size_t frames);
  void Fill(float* interleaved, size_t frames);

  raw_ptr<AudioManagerHaiku> manager_;
  const AudioParameters params_;
  // How far ahead the pump keeps the FIFO, in frames.
  const int target_frames_;
  haiku_shim::NativeSoundPlayer* player_ = nullptr;
  double volume_ = 1.0;
  // Read once after Start() on the audio thread. BSoundPlayer::Latency() is a
  // round trip to the player's own node, which is busy running Fill() while
  // the media kit thread is in it: asking from there deadlocks until the port
  // times out (about 13 s), stalling the whole graph after the first buffer.
  std::atomic<int64_t> latency_us_{0};

  std::unique_ptr<base::DelegateSimpleThread> pump_;

  base::Lock lock_;
  // Signalled whenever the FIFO drains below target_frames_ or on stop.
  base::ConditionVariable fifo_cv_{&lock_};
  bool stopping_ GUARDED_BY(lock_) = false;
  // Only written on the audio thread while the pump is not running; the pump
  // reads it under lock_ and calls it with lock_ released.
  raw_ptr<AudioSourceCallback> callback_ GUARDED_BY(lock_) = nullptr;
  std::unique_ptr<AudioBus> bus_;  // pump thread only
  std::unique_ptr<AudioBus> out_bus_ GUARDED_BY(lock_);
  std::unique_ptr<AudioFifo> fifo_ GUARDED_BY(lock_);
  // Frames of silence handed to the media kit since the last OnMoreData().
  int underrun_frames_ GUARDED_BY(lock_) = 0;
  int underruns_total_ GUARDED_BY(lock_) = 0;
};

}  // namespace media

#endif  // MEDIA_AUDIO_HAIKU_AUDIO_OUTPUT_STREAM_HAIKU_H_
