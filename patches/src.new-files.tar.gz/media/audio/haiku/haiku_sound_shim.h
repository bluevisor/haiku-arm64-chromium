// Copyright 2026 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef MEDIA_AUDIO_HAIKU_HAIKU_SOUND_SHIM_H_
#define MEDIA_AUDIO_HAIKU_HAIKU_SOUND_SHIM_H_

#include <stddef.h>
#include <stdint.h>

// The sound half of libchromium_haiku's C interface (see
// ui/ozone/platform/haiku/haiku_shim.h for why the BeAPI stays behind one).
// BSoundPlayer lives in libmedia, which this process never links.
namespace haiku_shim {

struct NativeSoundPlayer;
typedef void (*HaikuShimSoundFillFunc)(void* cookie,
                                       float* interleaved,
                                       size_t frames);

extern "C" {
NativeSoundPlayer* HaikuShimSoundPlayerCreate(int sample_rate,
                                              int channels,
                                              int frames_per_buffer,
                                              HaikuShimSoundFillFunc fill,
                                              void* cookie);
bool HaikuShimSoundPlayerStart(NativeSoundPlayer* player);
void HaikuShimSoundPlayerStop(NativeSoundPlayer* player);
void HaikuShimSoundPlayerSetVolume(NativeSoundPlayer* player, float volume);
int64_t HaikuShimSoundPlayerLatencyUs(NativeSoundPlayer* player);
void HaikuShimSoundPlayerDestroy(NativeSoundPlayer* player);
}

}  // namespace haiku_shim

#endif  // MEDIA_AUDIO_HAIKU_HAIKU_SOUND_SHIM_H_
