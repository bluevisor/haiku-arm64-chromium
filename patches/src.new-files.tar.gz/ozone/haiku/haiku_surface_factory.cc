// Copyright 2026 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "ui/ozone/platform/haiku/haiku_surface_factory.h"

#include <Bitmap.h>
#include <GraphicsDefs.h>

#include <memory>

#include "base/compiler_specific.h"
#include "base/memory/scoped_refptr.h"
#include "skia/ext/legacy_display_globals.h"
#include "third_party/skia/include/core/SkCanvas.h"
#include "base/containers/heap_array.h"
#include "base/containers/span.h"
#include "base/functional/bind.h"
#include "base/task/single_thread_task_runner.h"
#include "ui/gl/gl_bindings.h"
#include "ui/ozone/common/gl_surface_egl_readback.h"
#include "third_party/skia/include/core/SkImageInfo.h"
#include "third_party/skia/include/core/SkPixmap.h"
#include "third_party/skia/include/core/SkSurface.h"
#include "third_party/skia/include/core/SkSurfaceProps.h"
#include "ui/gfx/geometry/rect.h"
#include "ui/gfx/geometry/size.h"
#include "ui/gfx/vsync_provider.h"
#include "ui/gl/gl_display.h"
#include "ui/gl/gl_implementation.h"
#include "ui/gl/gl_surface.h"
#include "ui/gl/gl_surface_egl.h"
#include "ui/ozone/common/egl_util.h"
#include "ui/ozone/common/gl_ozone_egl.h"
#include "ui/ozone/platform/haiku/haiku_window.h"
#include "ui/ozone/platform/haiku/haiku_window_manager.h"
#include "ui/ozone/public/surface_ozone_canvas.h"

namespace ui {

namespace {

// Skia's N32 premultiplied layout is BGRA on little-endian, which is exactly
// B_RGBA32 -- so the copy below is a straight memcpy per row with no channel
// swizzling.
class HaikuCanvasSurface : public SurfaceOzoneCanvas {
 public:
  explicit HaikuCanvasSurface(scoped_refptr<HaikuPresentTarget> target)
      : target_(std::move(target)) {}

  ~HaikuCanvasSurface() override = default;

  void ResizeCanvas(const gfx::Size& viewport_size, float scale) override {
    size_ = viewport_size;
    SkSurfaceProps props = skia::LegacyDisplayGlobals::GetSkSurfaceProps();
    surface_ = SkSurfaces::Raster(
        SkImageInfo::MakeN32Premul(viewport_size.width(),
                                   viewport_size.height()),
        &props);
  }

  SkCanvas* GetCanvas() override {
    return surface_ ? surface_->getCanvas() : nullptr;
  }

  void PresentCanvas(const gfx::Rect& damage) override {
    if (!surface_ || !target_) {
      return;
    }
    SkPixmap pixmap;
    if (!surface_->peekPixels(&pixmap)) {
      return;
    }

    BRect bounds(0, 0, size_.width() - 1, size_.height() - 1);
    auto bitmap = std::make_unique<BBitmap>(bounds, B_RGBA32);
    if (bitmap->InitCheck() != B_OK) {
      return;
    }

    const int32 dst_stride = bitmap->BytesPerRow();
    const size_t src_stride = pixmap.rowBytes();
    const size_t row_bytes =
        static_cast<size_t>(size_.width()) * 4u;
    auto* dst = static_cast<uint8_t*>(bitmap->Bits());
    const auto* src = static_cast<const uint8_t*>(pixmap.addr());
    // SAFETY: dst is BBitmap::Bits(), sized dst_stride * size_.height() by
    // BBitmap's own allocation for these `bounds`; src is the raster
    // surface's pixels, sized src_stride * size_.height() by the
    // SkSurfaces::Raster() call in ResizeCanvas() above with this same
    // size_. row_bytes (width * 4, RGBA8) is <= both strides, and y is
    // bounded by size_.height(), so every access stays within both buffers.
    for (int y = 0; y < size_.height(); ++y) {
      UNSAFE_BUFFERS(memcpy(dst + static_cast<size_t>(y) * dst_stride,
                            src + static_cast<size_t>(y) * src_stride,
                            row_bytes));
    }

    // The window takes ownership; it holds the bitmap as its front buffer so
    // that expose events can repaint without a new frame. This runs on the
    // compositor thread, which is why the handle is a HaikuPresentTarget and
    // not a base::WeakPtr -- see haiku_window.h.
    target_->Present(bitmap.release(), damage);
  }

  std::unique_ptr<gfx::VSyncProvider> CreateVSyncProvider() override {
    return nullptr;
  }

 private:
  scoped_refptr<HaikuPresentTarget> target_;
  sk_sp<SkSurface> surface_;
  gfx::Size size_;
};

}  // namespace

namespace {

// The "view" surface for GPU compositing. app_server has no GL or Vulkan
// surface to hand out, so this is the same shape the X11 backend uses without
// GLX (GLSurfaceEglReadbackX11): viz renders the frame into an EGL pbuffer on
// ANGLE, SwapBuffers() reads the pixels back, and they go to the BWindow the
// way the software compositor's bitmaps do. ANGLE on Venus makes the GPU side
// of that the host GPU; the readback is one BGRA copy per frame.
class GLSurfaceEglReadbackHaiku : public GLSurfaceEglReadback {
 public:
  GLSurfaceEglReadbackHaiku(gl::GLDisplayEGL* display,
                            scoped_refptr<HaikuPresentTarget> target)
      : GLSurfaceEglReadback(display), target_(std::move(target)) {}

  GLSurfaceEglReadbackHaiku(const GLSurfaceEglReadbackHaiku&) = delete;
  GLSurfaceEglReadbackHaiku& operator=(const GLSurfaceEglReadbackHaiku&) =
      delete;

 protected:
  ~GLSurfaceEglReadbackHaiku() override = default;

  // GLSurface:
  bool SupportsPostSubBuffer() override { return true; }

  // Only the damaged rows leave the GPU: viz passes the damage rect in this
  // surface's (top-left) origin, which is also the row order glReadPixels
  // gives for a frame rendered for a top-left origin, so no flip.
  gfx::SwapResult PostSubBuffer(int x,
                                int y,
                                int width,
                                int height,
                                PresentationCallback callback,
                                gfx::FrameData data) override {
    const gfx::Size size = GetSize();
    gfx::Rect rect(x, y, width, height);
    rect.Intersect(gfx::Rect(size));
    bool ok = true;
    if (!rect.IsEmpty() && target_) {
      const size_t row_bytes = static_cast<size_t>(rect.width()) * 4u;
      const size_t needed = row_bytes * static_cast<size_t>(rect.height());
      if (scratch_.size() < needed) {
        scratch_ = base::HeapArray<uint8_t>::Uninit(needed);
      }
      ReadRect(rect, scratch_.as_span());
      const uint8_t* src = scratch_.data();
      ok = target_->UpdateFrontBuffer(
          size, rect, [&](uint8_t* pixels, int stride) {
            // SAFETY: pixels is the front buffer, stride * size.height()
            // bytes; rect is inside size; src holds rect.height() rows of
            // row_bytes.
            for (int r = 0; r < rect.height(); ++r) {
              UNSAFE_BUFFERS(memcpy(
                  pixels + static_cast<size_t>(rect.y() + r) * stride +
                      static_cast<size_t>(rect.x()) * 4u,
                  src + static_cast<size_t>(r) * row_bytes, row_bytes));
            }
          });
    }
    gfx::PresentationFeedback feedback;
    feedback.timestamp = base::TimeTicks::Now();
    task_runner_->PostTask(FROM_HERE,
                           base::BindOnce(std::move(callback), feedback));
    return ok ? gfx::SwapResult::SWAP_ACK : gfx::SwapResult::SWAP_FAILED;
  }

  // GLSurfaceEglReadback:
  bool HandlePixels(uint8_t* pixels) override {
    const gfx::Size size = GetSize();
    if (size.IsEmpty() || !target_) {
      return false;
    }
    // glReadPixels gave tightly packed BGRA rows, top row first (the base
    // class reports a top-left origin, so viz renders the frame that way
    // up). B_RGBA32 is the same byte order. This runs on the GPU thread; the
    // handle is a HaikuPresentTarget for the same reason the canvas uses one.
    const size_t src_stride = static_cast<size_t>(size.width()) * 4u;
    return target_->UpdateFrontBuffer(
        size, gfx::Rect(size), [&](uint8_t* dst, int dst_stride) {
          // SAFETY: pixels is the base class's readback buffer of
          // width * height * 4 bytes for this same GetSize(); dst is the
          // front buffer, dst_stride * height bytes. Each row copies
          // src_stride <= dst_stride bytes and y < height.
          for (int y = 0; y < size.height(); ++y) {
            UNSAFE_BUFFERS(memcpy(dst + static_cast<size_t>(y) * dst_stride,
                                  pixels + static_cast<size_t>(y) * src_stride,
                                  src_stride));
          }
        });
  }

 private:
  // glReadPixels of `rect` from the default framebuffer into `out`, BGRA,
  // tightly packed, the way the base class reads the whole surface.
  void ReadRect(const gfx::Rect& rect, base::span<uint8_t> out) {
    GLint read_fbo = 0;
    GLint pixel_pack_buffer = 0;
    glGetIntegerv(GL_READ_FRAMEBUFFER_BINDING, &read_fbo);
    glGetIntegerv(GL_PIXEL_PACK_BUFFER_BINDING, &pixel_pack_buffer);
    if (read_fbo) {
      glBindFramebufferEXT(GL_READ_FRAMEBUFFER, 0);
    }
    if (pixel_pack_buffer) {
      glBindBuffer(GL_PIXEL_PACK_BUFFER, 0);
    }
    glReadPixels(rect.x(), rect.y(), rect.width(), rect.height(), GL_BGRA_EXT,
                 GL_UNSIGNED_BYTE, out.data());
    if (read_fbo) {
      glBindFramebufferEXT(GL_READ_FRAMEBUFFER, read_fbo);
    }
    if (pixel_pack_buffer) {
      glBindBuffer(GL_PIXEL_PACK_BUFFER, pixel_pack_buffer);
    }
  }

  scoped_refptr<HaikuPresentTarget> target_;
  scoped_refptr<base::SingleThreadTaskRunner> task_runner_ =
      base::SingleThreadTaskRunner::GetCurrentDefault();
  base::HeapArray<uint8_t> scratch_;
};

// EGL on ANGLE (statically linked; its Vulkan backend is whatever
// lib/libvulkan.so.1 or venus/libvulkan.so.1 resolves to). A view surface is
// a readback surface onto the window; offscreen surfaces are plain pbuffers.
class GLOzoneEGLHaiku : public GLOzoneEGL {
 public:
  explicit GLOzoneEGLHaiku(HaikuWindowManager* window_manager)
      : window_manager_(window_manager) {}
  GLOzoneEGLHaiku(const GLOzoneEGLHaiku&) = delete;
  GLOzoneEGLHaiku& operator=(const GLOzoneEGLHaiku&) = delete;
  ~GLOzoneEGLHaiku() override = default;

  // GLOzone:
  scoped_refptr<gl::GLSurface> CreateViewGLSurface(
      gl::GLDisplay* display,
      gfx::AcceleratedWidget window) override {
    // Null without a window manager (a GPU process of its own) and for a
    // widget this process does not own; viz then falls back to software
    // compositing through CreateCanvasForWidget().
    if (!window_manager_) {
      return nullptr;
    }
    HaikuWindow* haiku_window = window_manager_->GetWindow(window);
    if (!haiku_window) {
      return nullptr;
    }
    return gl::InitializeGLSurface(
        base::MakeRefCounted<GLSurfaceEglReadbackHaiku>(
            display->GetAs<gl::GLDisplayEGL>(),
            haiku_window->present_target()));
  }

  scoped_refptr<gl::GLSurface> CreateOffscreenGLSurface(
      gl::GLDisplay* display,
      const gfx::Size& size) override {
    return gl::InitializeGLSurface(
        base::MakeRefCounted<gl::PbufferGLSurfaceEGL>(
            display->GetAs<gl::GLDisplayEGL>(), size));
  }

 protected:
  // GLOzoneEGL:
  gl::EGLDisplayPlatform GetNativeDisplay() override {
    return gl::EGLDisplayPlatform(EGL_DEFAULT_DISPLAY);
  }

  bool LoadGLES2Bindings(
      const gl::GLImplementationParts& implementation) override {
    return LoadDefaultEGLGLES2Bindings(implementation);
  }

 private:
  // Null in a GPU process of its own; see CreateCanvasForWidget().
  raw_ptr<HaikuWindowManager> window_manager_;
};

}  // namespace

HaikuSurfaceFactory::HaikuSurfaceFactory(HaikuWindowManager* window_manager)
    : window_manager_(window_manager),
      egl_implementation_(std::make_unique<GLOzoneEGLHaiku>(window_manager)) {}

HaikuSurfaceFactory::~HaikuSurfaceFactory() = default;

std::vector<gl::GLImplementationParts>
HaikuSurfaceFactory::GetAllowedGLImplementations() {
  return {gl::GLImplementationParts(gl::kGLImplementationEGLANGLE)};
}

GLOzone* HaikuSurfaceFactory::GetGLOzone(
    const gl::GLImplementationParts& implementation) {
  return implementation.gl == gl::kGLImplementationEGLANGLE
             ? egl_implementation_.get()
             : nullptr;
}

std::unique_ptr<SurfaceOzoneCanvas> HaikuSurfaceFactory::CreateCanvasForWidget(
    gfx::AcceleratedWidget widget) {
  // Null in a GPU process: InitializeGPU() builds this factory without a
  // window manager because the windows are in the browser process. Chrome
  // asks for viz to run in-process on this platform for that reason, but a
  // command line can still put it in a process of its own, and returning no
  // canvas is a great deal better than dereferencing nothing.
  if (!window_manager_) {
    return nullptr;
  }
  HaikuWindow* window = window_manager_->GetWindow(widget);
  if (!window) {
    return nullptr;
  }
  return std::make_unique<HaikuCanvasSurface>(window->present_target());
}

}  // namespace ui
