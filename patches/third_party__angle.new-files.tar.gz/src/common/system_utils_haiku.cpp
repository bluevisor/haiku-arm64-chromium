// Copyright 2026 The RENKU project
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// The system utilities ANGLE keeps in its Linux file rather than its POSIX
// one. Haiku has no /proc/self/exe (the app image's path comes from
// get_next_image_info) and no CLOCK_MONOTONIC_RAW, and it names threads with
// rename_thread() instead of prctl().

#include "common/system_utils.h"

#include <OS.h>
#include <image.h>
#include <time.h>

namespace angle
{
std::string GetExecutablePath()
{
    image_info info;
    int32 cookie = 0;
    while (get_next_image_info(B_CURRENT_TEAM, &cookie, &info) == B_OK)
    {
        if (info.type == B_APP_IMAGE)
        {
            return info.name;
        }
    }
    return "";
}

std::string GetExecutableDirectory()
{
    std::string executablePath = GetExecutablePath();
    size_t lastPathSepLoc      = executablePath.find_last_of("/");
    return (lastPathSepLoc != std::string::npos) ? executablePath.substr(0, lastPathSepLoc) : "";
}

const char *GetSharedLibraryExtension()
{
    return "so";
}

double GetCurrentSystemTime()
{
    struct timespec currentTime;
    clock_gettime(CLOCK_MONOTONIC, &currentTime);
    return currentTime.tv_sec + currentTime.tv_nsec * 1e-9;
}

uint64_t GetCurrentSystemTimeNs()
{
    struct timespec currentTime;
    clock_gettime(CLOCK_MONOTONIC, &currentTime);
    return static_cast<uint64_t>(currentTime.tv_sec) * 1000'000'000 + currentTime.tv_nsec;
}

void SetCurrentThreadName(const char *name)
{
    rename_thread(find_thread(nullptr), name);
}
}  // namespace angle
